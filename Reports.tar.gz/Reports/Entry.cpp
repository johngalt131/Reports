/*
 * Entry.cpp
 *
 *  Created on: Sep 11, 2011
 *      Author: travisstaley
 */

#include "Entry.h"

Entry::Entry() {
	// TODO Auto-generated constructor stub

}

Entry::~Entry() {
	// TODO Auto-generated destructor stub
}
