/*
 * Entry.h
 *
 *  Created on: Sep 11, 2011
 *      Author: travisstaley
 */

#ifndef ENTRY_H_
#define ENTRY_H_

class Entry {
public:
	Entry();
	virtual ~Entry();
};

#endif /* ENTRY_H_ */
